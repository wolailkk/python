config = {
    'workPath':"/tmp/git/",#git 项目工作目录
    'outputPath':"/tmp/",#版本输出目录
    'zipPath':"vendor",#需要压缩的目录
    'fileName':"/composer.json",#版本控制主体文件
    'redisPort':6377,#redis端口号
    'redisHost':'127.0.0.1',#redishost
    'queue':'sync_job',#队列名称
}